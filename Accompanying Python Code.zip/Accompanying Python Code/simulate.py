"""Eight reproducible figures for main.tex: one leader, one follower.

Uses inertial-velocity errors, forward Euler, discounted common/private
Riccati equations, and information-admissible feedback.
Run: python simulate.py
Only files inside this script's directory are written.
"""
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as path_effects
from matplotlib.text import Text
from matplotlib.ticker import FuncFormatter, MaxNLocator
import numpy as np

ROOT = Path(__file__).resolve().parent
BLUE = "#0072BD"
ORANGE = "#D95319"


def sym(matrix):
    return (matrix + matrix.T) / 2


def build_model(cfg):
    step = float(cfg["sampling_period"])
    eye = np.eye(3)
    ad = np.block([[eye, step * eye], [np.zeros((3, 3)), eye]])
    bd = np.vstack((np.zeros((3, 3)), step * eye))
    c = cfg["coupling"]
    # Nonzero acceleration couplings preserve dot(z^1)=z^2.
    a10 = bd @ np.hstack((
        c["leader_position_error_coefficient"] * eye,
        c["leader_velocity_error_coefficient"] * eye))
    b10 = c["leader_input_coefficient"] * bd
    a = np.block([[ad, np.zeros((6, 6))], [a10, ad]])
    b = np.block([[bd, np.zeros((6, 3))], [b10, bd]])
    qa = np.diag(cfg["own_state_weight"])
    qf = np.diag(cfg["relative_error_weight"])
    q = np.block([[qa + qf, -qf], [-qf, qa + qf]])
    rb = np.diag(cfg["input_weight"])
    rc = cfg["input_cross_weight_ratio"] * rb
    r = np.block([[rb, rc], [rc.T, rb]])
    cost_scale = float(cfg.get("cost_weight_scale", 1.0))
    if not np.isfinite(cost_scale) or cost_scale <= 0:
        raise ValueError("The common cost-weight scale must be positive.")
    q = cost_scale * q
    r = cost_scale * r
    mu = np.asarray(cfg["initial_means"], dtype=float)
    initial_std = np.asarray(cfg["initial_standard_deviations"], dtype=float)
    acceleration_std = np.asarray(
        cfg["acceleration_noise_standard_deviations"], dtype=float)
    covariance = [np.diag(row ** 2) for row in initial_std]
    noise_covariance = [
        bd @ np.diag(row ** 2) @ bd.T for row in acceleration_std]
    assert np.linalg.eigvalsh(q).min() > 0
    assert np.linalg.eigvalsh(r).min() > 0
    assert np.linalg.norm(a10) > 0 and np.linalg.norm(b10) > 0
    return dict(
        cfg=cfg, gamma=float(cfg["discount_factor"]), T=step,
        Ad=ad, Bd=bd, A10=a10, B10=b10, A=a, B=b, Q=q, R=r,
        Q11=q[6:, 6:], R11=r[3:, 3:], mu=mu,
        initial_std=initial_std, acceleration_std=acceleration_std,
        Xi=covariance, W=noise_covariance)


def riccati_step(a, b, q, r, p_next, gamma):
    gain = np.linalg.solve(
        r + gamma * b.T @ p_next @ b,
        gamma * b.T @ p_next @ a)
    p = q + gamma * a.T @ p_next @ (a - b @ gain)
    return sym(p), gain


def solve_discounted_are(a, b, q, r, gamma):
    p = np.zeros_like(q)
    for iteration in range(1, 20001):
        candidate, _ = riccati_step(a, b, q, r, p, gamma)
        error = np.linalg.norm(candidate - p, ord="fro")
        p = candidate
        if error < 1e-13 * max(1.0, np.linalg.norm(p, ord="fro")):
            break
    else:
        raise RuntimeError("Discounted Riccati iteration did not converge.")
    residual_p, gain = riccati_step(a, b, q, r, p, gamma)
    return p, gain, iteration, float(np.max(np.abs(residual_p - p)))


def stationary_solution(m):
    p, h, n1, err1 = solve_discounted_are(
        m["A"], m["B"], m["Q"], m["R"], m["gamma"])
    s, omega, n2, err2 = solve_discounted_are(
        m["Ad"], m["Bd"], m["Q11"], m["R11"], m["gamma"])
    common = m["A"] - m["B"] @ h
    private = m["Ad"] - m["Bd"] @ omega
    radii = [
        float(np.max(np.abs(np.linalg.eigvals(common)))),
        float(np.max(np.abs(np.linalg.eigvals(private))))]
    if max(radii) >= 1:
        raise RuntimeError("The unscaled physical closed loops must be Schur.")
    margins = [
        float(np.linalg.eigvalsh(
            m["Q"] + h.T @ m["R"] @ h - (1 - m["gamma"]) * p).min()),
        float(np.linalg.eigvalsh(
            m["Q11"] + omega.T @ m["R11"] @ omega
            - (1 - m["gamma"]) * s).min())]
    assert min(margins) > 0
    return dict(P=p, H=h, S=s, Omega=omega, common=common, private=private,
                radii=radii, margins=margins,
                are_residuals=[err1, err2],
                are_relative_residuals=[
                    err1 / max(1.0, np.linalg.norm(p, ord=np.inf)),
                    err2 / max(1.0, np.linalg.norm(s, ord=np.inf))],
                iterations=[n1, n2])


def finite_value_curve(m, largest_n):
    """For each N: stages 0,...,N, discount gamma, zero terminal at N+1."""
    p = np.zeros((12, 12))
    s = np.zeros((6, 6))
    constant = 0.0
    mu = m["mu"].reshape(12)
    values = []
    for _ in range(largest_n + 1):
        # Use the PREVIOUS remaining-horizon matrices in the noise term.
        constant = m["gamma"] * (
            constant + np.trace(p[:6, :6] @ m["W"][0])
            + np.trace(s @ m["W"][1]))
        p, _ = riccati_step(
            m["A"], m["B"], m["Q"], m["R"], p, m["gamma"])
        s, _ = riccati_step(
            m["Ad"], m["Bd"], m["Q11"], m["R11"], s, m["gamma"])
        values.append(
            mu @ p @ mu + np.trace(p[:6, :6] @ m["Xi"][0])
            + np.trace(s @ m["Xi"][1]) + constant)
    return np.asarray(values)


def infinite_value(m, sol):
    mu = m["mu"].reshape(12)
    noise_trace = (
        np.trace(sol["P"][:6, :6] @ m["W"][0])
        + np.trace(sol["S"] @ m["W"][1]))
    return float(
        mu @ sol["P"] @ mu
        + np.trace(sol["P"][:6, :6] @ m["Xi"][0])
        + np.trace(sol["S"] @ m["Xi"][1])
        + m["gamma"] / (1 - m["gamma"]) * noise_trace)


def reference(times, cfg):
    par = cfg["reference"]
    v, amplitude, frequency = (
        par["forward_speed"], par["sine_amplitude"], par["angular_frequency"])
    phase = frequency * times
    ratio = amplitude * frequency / v * np.cos(phase)
    ratio_dot = -amplitude * frequency ** 2 / v * np.sin(phase)
    ratio_ddot = -amplitude * frequency ** 3 / v * np.cos(phase)
    yaw = np.arctan(ratio)
    yaw_rate = ratio_dot / (1 + ratio ** 2)
    yaw_acc = (ratio_ddot / (1 + ratio ** 2)
               - 2 * ratio * ratio_dot ** 2 / (1 + ratio ** 2) ** 2)
    eta0 = np.column_stack((v * times, amplitude * np.sin(phase), yaw))
    velocity0 = np.column_stack((
        np.full_like(times, v), amplitude * frequency * np.cos(phase), yaw_rate))
    acceleration0 = np.column_stack((
        np.zeros_like(times), -amplitude * frequency ** 2 * np.sin(phase), yaw_acc))
    offsets = np.array([[0.0, 0.0, 0.0], par["follower_offset"]])
    eta = eta0[:, None, :] + offsets[None, :, :]
    velocity = np.repeat(velocity0[:, None, :], 2, axis=1)
    acceleration = np.repeat(acceleration0[:, None, :], 2, axis=1)
    return eta, velocity, acceleration


def controller(m, sol, state, estimate):
    common_state = np.r_[state[:6], estimate]
    common_input = -sol["H"] @ common_state
    action = common_input.copy()
    action[3:] -= sol["Omega"] @ (state[6:] - estimate)
    return action, common_input


def simulate_one(m, sol, initial, noise):
    steps = len(noise)
    state = np.empty((steps + 1, 12))
    estimate = np.empty((steps + 1, 6))
    action = np.empty((steps + 1, 6))
    state[0] = initial.reshape(12)
    estimate[0] = m["mu"][1]
    private_residual = 0.0
    for k in range(steps + 1):
        action[k], common_input = controller(m, sol, state[k], estimate[k])
        if k == steps:
            break
        w = (noise[k] @ m["Bd"].T).reshape(12)
        state[k + 1] = m["A"] @ state[k] + m["B"] @ action[k] + w
        estimate[k + 1] = (
            m["Ad"] @ estimate[k] + m["Bd"] @ common_input[3:]
            + m["A10"] @ state[k, :6] + m["B10"] @ action[k, :3])
        error = state[k, 6:] - estimate[k]
        next_error = state[k + 1, 6:] - estimate[k + 1]
        private_residual = max(private_residual, float(np.max(np.abs(
            next_error - sol["private"] @ error - w[6:]))))
    return dict(state=state, estimate=estimate, action=action,
                private_recursion_residual=private_residual)


def forces_and_states(m, run, eta_d, vel_d, acc_d):
    """Equation (75) nominal body-frame force/moment demands.

    Selected leader acceleration coupling is a separate modeled channel.
    Its equivalent generalized force is saved separately, not combined
    with the actuator force defined by equation (75).
    """
    error = run["state"].reshape(-1, 2, 6)
    eta = eta_d + error[:, :, :3]
    velocity = vel_d + error[:, :, 3:]
    action = run["action"].reshape(-1, 2, 3)
    body_velocity = np.empty_like(eta)
    tau = np.empty_like(eta)
    interaction_force = np.zeros_like(eta)
    interaction_acc = np.zeros_like(eta)
    residual, coupled_residual = 0.0, 0.0
    for k in range(len(eta)):
        interaction_acc[k, 1] = (
            m["A10"] @ run["state"][k, :6]
            + m["B10"] @ run["action"][k, :3])[3:] / m["T"]
        for i in range(2):
            mass = np.asarray(m["cfg"]["nominal_inertia_matrices"][i])
            damping = np.diag(m["cfg"]["nominal_damping_diagonals"][i])
            angle = eta[k, i, 2]
            co, si = np.cos(angle), np.sin(angle)
            rotation = np.array([[co, -si, 0], [si, co, 0], [0, 0, 1.0]])
            nu = rotation.T @ velocity[k, i]
            body_velocity[k, i] = nu
            rotation_dot = nu[2] * np.array(
                [[-si, -co, 0], [co, -si, 0], [0, 0, 0.0]])
            momentum = mass @ nu
            px, py = momentum[:2]
            coriolis = np.array([[0, 0, -py], [0, 0, px], [py, -px, 0]])
            h_term = (mass @ rotation.T @ rotation_dot @ nu
                      - coriolis @ nu - damping @ nu)
            tau[k, i] = mass @ rotation.T @ (
                action[k, i] + acc_d[k, i]) - h_term
            interaction_force[k, i] = (
                mass @ rotation.T @ interaction_acc[k, i])
            # Independent forward evaluation of the marine vector field.
            nu_dot = np.linalg.solve(
                mass, tau[k, i] - coriolis @ nu - damping @ nu)
            recovered_acc = rotation_dot @ nu + rotation @ nu_dot
            residual = max(residual, float(np.max(np.abs(
                recovered_acc - acc_d[k, i] - action[k, i]))))
            coupled_acc = rotation_dot @ nu + rotation @ np.linalg.solve(
                mass, tau[k, i] + interaction_force[k, i]
                - coriolis @ nu - damping @ nu)
            coupled_residual = max(coupled_residual, float(np.max(np.abs(
                coupled_acc - acc_d[k, i] - action[k, i]
                - interaction_acc[k, i]))))
    return dict(eta=eta, velocity=velocity, nu=body_velocity, tau=tau,
                coupling_force=interaction_force,
                coupling_acceleration=interaction_acc,
                inverse_residual=residual, coupled_residual=coupled_residual)


def exact_policy_cost(m, gains, private_gains):
    """Independent expected-cost evaluation by forward moment propagation."""
    mean = m["mu"].reshape(12)
    common_cov = np.zeros((12, 12))
    common_cov[:6, :6] = m["Xi"][0]
    private_cov = m["Xi"][1].copy()
    common_noise = np.zeros((12, 12))
    common_noise[:6, :6] = m["W"][0]
    value = 0.0
    for k, (h, omega) in enumerate(zip(gains, private_gains)):
        common_weight = m["Q"] + h.T @ m["R"] @ h
        private_weight = m["Q11"] + omega.T @ m["R11"] @ omega
        value += m["gamma"] ** k * (
            mean @ common_weight @ mean
            + np.trace(common_weight @ common_cov)
            + np.trace(private_weight @ private_cov))
        fc = m["A"] - m["B"] @ h
        fp = m["Ad"] - m["Bd"] @ omega
        mean = fc @ mean
        common_cov = fc @ common_cov @ fc.T + common_noise
        private_cov = fp @ private_cov @ fp.T + m["W"][1]
    return float(value)


def finite_gains(m, stages):
    p, s = np.zeros((12, 12)), np.zeros((6, 6))
    gains, private_gains = [], []
    for _ in range(stages):
        p, gain = riccati_step(
            m["A"], m["B"], m["Q"], m["R"], p, m["gamma"])
        s, private_gain = riccati_step(
            m["Ad"], m["Bd"], m["Q11"], m["R11"], s, m["gamma"])
        gains.append(gain)
        private_gains.append(private_gain)
    return gains[::-1], private_gains[::-1]


def monte_carlo_value(m, sol):
    cfg = m["cfg"]
    count, stages = cfg["monte_carlo_runs"], cfg["monte_carlo_steps"]
    rng = np.random.default_rng(cfg["seed"] + 1)
    state = (m["mu"][None] + m["initial_std"][None]
             * rng.standard_normal((count, 2, 6))).reshape(count, 12)
    estimate = np.repeat(m["mu"][None, 1], count, axis=0)
    total = np.zeros(count)
    for k in range(stages):
        common_state = np.column_stack((state[:, :6], estimate))
        common_input = -common_state @ sol["H"].T
        action = common_input.copy()
        action[:, 3:] -= (state[:, 6:] - estimate) @ sol["Omega"].T
        total += m["gamma"] ** k * (
            np.einsum("ri,ij,rj->r", state, m["Q"], state)
            + np.einsum("ri,ij,rj->r", action, m["R"], action))
        noise = rng.standard_normal((count, 2, 3)) * m["acceleration_std"]
        w = (noise @ m["Bd"].T).reshape(count, 12)
        estimate = (
            estimate @ m["Ad"].T + common_input[:, 3:] @ m["Bd"].T
            + state[:, :6] @ m["A10"].T + action[:, :3] @ m["B10"].T)
        state = state @ m["A"].T + action @ m["B"].T + w
    # Unbiased sample evaluation of the discounted stationary terminal tail.
    common_state = np.column_stack((state[:, :6], estimate))
    private_error = state[:, 6:] - estimate
    tail_constant = m["gamma"] / (1 - m["gamma"]) * (
        np.trace(sol["P"][:6, :6] @ m["W"][0])
        + np.trace(sol["S"] @ m["W"][1]))
    total += m["gamma"] ** stages * (
        np.einsum("ri,ij,rj->r", common_state, sol["P"], common_state)
        + np.einsum("ri,ij,rj->r", private_error, sol["S"], private_error)
        + tail_constant)
    mean = float(total.mean())
    standard_error = float(total.std(ddof=1) / np.sqrt(count))
    return dict(runs=count, mean=mean, standard_error=standard_error,
                confidence_interval_95=[mean - 1.96 * standard_error,
                                        mean + 1.96 * standard_error])


def physical_input_penalty_matrix(m):
    """Constant normalized force/moment weights, with proper SI scales."""
    scales = np.asarray(m["cfg"]["physical_force_reference_scales"], dtype=float)
    multiplier = float(m["cfg"]["physical_force_penalty_multiplier"])
    if scales.shape != (2, 3) or np.any(scales <= 0) or multiplier <= 0:
        raise ValueError("Provide positive surge/sway/moment scales for each boat.")
    inverse_scale = np.diag(1 / scales.reshape(6))
    weight = multiplier * inverse_scale @ m["R"] @ inverse_scale
    assert np.linalg.eigvalsh(weight).min() > 0
    return weight


def physical_force_batch(m, state, action, eta_d, vel_d, acc_d):
    """Vectorized TOTAL equation (75) forces, including feedforward and drag."""
    error = state.reshape(state.shape[:-1] + (2, 6))
    pose = eta_d + error[..., :3]
    velocity = vel_d + error[..., 3:]
    co, si = np.cos(pose[..., 2]), np.sin(pose[..., 2])
    nu = np.stack((
        co * velocity[..., 0] + si * velocity[..., 1],
        -si * velocity[..., 0] + co * velocity[..., 1],
        velocity[..., 2]), axis=-1)
    rotation_dot_nu = np.stack((
        -velocity[..., 2] * velocity[..., 1],
        velocity[..., 2] * velocity[..., 0],
        np.zeros_like(velocity[..., 2])), axis=-1)
    inertial_acc = action.reshape(action.shape[:-1] + (2, 3)) + acc_d - rotation_dot_nu
    body_acc = np.stack((
        co * inertial_acc[..., 0] + si * inertial_acc[..., 1],
        -si * inertial_acc[..., 0] + co * inertial_acc[..., 1],
        inertial_acc[..., 2]), axis=-1)
    masses = np.asarray(m["cfg"]["nominal_inertia_matrices"])
    damping = np.asarray(m["cfg"]["nominal_damping_diagonals"])
    momentum = np.einsum("aij,...aj->...ai", masses, nu)
    px, py = momentum[..., 0], momentum[..., 1]
    coriolis = np.stack((
        -py * nu[..., 2], px * nu[..., 2],
        py * nu[..., 0] - px * nu[..., 1]), axis=-1)
    return np.einsum("aij,...aj->...ai", masses, body_acc) + coriolis + damping * nu


def physical_cost_evaluation(m, sol, representative, physical, ref, ref_v, ref_a):
    """Evaluate the unchanged virtual-optimal policy under a physical criterion.

    This is a Monte Carlo expected cumulative cost, NOT a claimed optimum
    for the changed nonlinear force/moment objective.
    """
    cfg = m["cfg"]
    count = int(cfg["physical_cost_monte_carlo_runs"])
    steps = int(cfg["simulation_steps"])
    rng = np.random.default_rng(cfg["seed"] + 2)
    state = (m["mu"][None] + m["initial_std"][None]
             * rng.standard_normal((count, 2, 6))).reshape(count, 12)
    estimate = np.repeat(m["mu"][None, 1], count, axis=0)
    weight = physical_input_penalty_matrix(m)
    cumulative_state, cumulative_force, cumulative_virtual = [
        np.zeros(count) for _ in range(3)]
    samples = np.empty((count, steps + 1))
    mean, sem, state_part, force_part, virtual_mean, virtual_sem = [
        np.empty(steps + 1) for _ in range(6)]
    mean_state_stage, mean_force_stage, variance_penalty = [
        np.empty(steps + 1) for _ in range(3)]
    state_mean = np.empty((steps + 1, 2, 6))
    state_sem = np.empty_like(state_mean)
    force_mean = np.empty((steps + 1, 2, 3))
    force_sem = np.empty_like(force_mean)
    expected_state_mean = np.empty_like(state_mean)
    expected_mean = m["mu"].reshape(12).copy()
    covariance_identity_error = 0.0
    for k in range(steps + 1):
        common_state = np.column_stack((state[:, :6], estimate))
        common_input = -common_state @ sol["H"].T
        action = common_input.copy()
        action[:, 3:] -= (state[:, 6:] - estimate) @ sol["Omega"].T
        tau = physical_force_batch(
            m, state, action, ref[k], ref_v[k], ref_a[k]).reshape(count, 6)
        state_stage = np.einsum("ri,ij,rj->r", state, m["Q"], state)
        force_stage = np.einsum("ri,ij,rj->r", tau, weight, tau)
        virtual_stage = np.einsum("ri,ij,rj->r", action, m["R"], action)
        assert min(state_stage.min(), force_stage.min()) >= -1e-10
        discount = m["gamma"] ** k
        cumulative_state += discount * state_stage
        cumulative_force += discount * force_stage
        cumulative_virtual += discount * virtual_stage
        samples[:, k] = cumulative_state + cumulative_force
        virtual_samples = cumulative_state + cumulative_virtual
        mean[k] = samples[:, k].mean()
        sem[k] = samples[:, k].std(ddof=1) / np.sqrt(count)
        state_part[k] = cumulative_state.mean()
        force_part[k] = cumulative_force.mean()
        virtual_mean[k] = virtual_samples.mean()
        virtual_sem[k] = virtual_samples.std(ddof=1) / np.sqrt(count)
        mean_state_stage[k], mean_force_stage[k] = (
            state_stage.mean(), force_stage.mean())
        state_mean[k] = state.mean(axis=0).reshape(2, 6)
        state_sem[k] = (state.std(axis=0, ddof=1) / np.sqrt(count)).reshape(2, 6)
        expected_state_mean[k] = expected_mean.reshape(2, 6)
        mean_tau = tau.mean(axis=0)
        force_mean[k] = mean_tau.reshape(2, 3)
        force_sem[k] = (tau.std(axis=0, ddof=1) / np.sqrt(count)).reshape(2, 3)
        centered_tau = tau - mean_tau
        variance_penalty[k] = np.einsum(
            "ri,ij,rj->", centered_tau, weight, centered_tau) / count
        covariance_identity_error = max(covariance_identity_error, abs(
            mean_force_stage[k] - mean_tau @ weight @ mean_tau
            - variance_penalty[k]))
        if k == steps:
            break
        noise = rng.standard_normal((count, 2, 3)) * m["acceleration_std"]
        w = (noise @ m["Bd"].T).reshape(count, 12)
        estimate = (
            estimate @ m["Ad"].T + common_input[:, 3:] @ m["Bd"].T
            + state[:, :6] @ m["A10"].T + action[:, :3] @ m["B10"].T)
        state = state @ m["A"].T + action @ m["B"].T + w
        expected_mean = sol["common"] @ expected_mean
    force_identity_error = float(np.max(np.abs(physical_force_batch(
        m, representative["state"], representative["action"], ref, ref_v, ref_a)
        - physical["tau"])))
    exact_virtual_prefix = exact_policy_cost(
        m, [sol["H"]] * (steps + 1), [sol["Omega"]] * (steps + 1))
    assert force_identity_error < 1e-10
    assert covariance_identity_error < 1e-9
    assert np.min(np.diff(mean)) >= -1e-10
    assert np.max(np.abs(mean - state_part - force_part)) < 1e-9
    assert abs(virtual_mean[-1] - exact_virtual_prefix) < 4 * virtual_sem[-1]
    mean_standardized_error = float(np.max(
        np.abs(state_mean - expected_state_mean) / np.maximum(state_sem, 1e-15)))
    assert mean_standardized_error < 6
    return dict(
        time=np.arange(steps + 1) * m["T"], mean=mean, sem=sem,
        state_component=state_part, force_component=force_part,
        virtual_cost_mean=virtual_mean, virtual_cost_sem=virtual_sem,
        stage_state_mean=mean_state_stage, stage_force_mean=mean_force_stage,
        force_variance_penalty=variance_penalty, cost_samples=samples,
        state_mean=state_mean, state_sem=state_sem,
        force_mean=force_mean, force_sem=force_sem,
        expected_state_mean=expected_state_mean,
        R_tau=weight,
        validation=dict(
            passed=True, runs=count, seed=cfg["seed"] + 2,
            controller="stationary optimum for the original virtual-input objective",
            optimal_for_physical_objective_claimed=False,
            penalty="total equation (75) actuator forces and yaw moments",
            expected_quadratic_penalty_computed_before_averaging=True,
            force_reconstruction_identity_error=force_identity_error,
            mean_and_covariance_penalty_identity_error=float(covariance_identity_error),
            physical_prefix_cost_at_100s=float(mean[-1]),
            physical_prefix_cost_standard_error=float(sem[-1]),
            physical_prefix_cost_confidence_interval_95=[
                float(mean[-1] - 1.96 * sem[-1]), float(mean[-1] + 1.96 * sem[-1])],
            virtual_prefix_exact=float(exact_virtual_prefix),
            virtual_prefix_monte_carlo=float(virtual_mean[-1]),
            mean_response_figures=[3, 4, 9],
            mean_response_runs=count,
            mean_response_seed=cfg["seed"] + 2,
            error_statistic="signed arithmetic mean, not mean absolute error or RMSE",
            force_statistic="average of separately reconstructed total forces/moments",
            state_mean_maximum_standard_error=float(state_sem.max()),
            state_mean_vs_analytical_mean_maximum_standardized_error=mean_standardized_error,
            force_mean_maximum_standard_error=float(force_sem.max()),
            force_reference_scales=cfg["physical_force_reference_scales"],
            R_tau=weight.tolist()))


def configure_style(cfg):
    plt.rcParams.update({
        "font.family": "Times New Roman", "font.size": 10,
        "mathtext.fontset": "stix", "axes.labelsize": 11,
        "axes.linewidth": 0.65, "axes.edgecolor": "#222222",
        "xtick.labelsize": 10, "ytick.labelsize": 10,
        "xtick.direction": "in", "ytick.direction": "in",
        "xtick.top": True, "ytick.right": True,
        "xtick.major.size": 3, "ytick.major.size": 3,
        "legend.fancybox": False, "legend.framealpha": 1,
        "legend.facecolor": "white", "legend.edgecolor": "#222222",
        "lines.linewidth": cfg["line_width"], "axes.grid": False,
        "figure.facecolor": "white", "savefig.facecolor": "white",
        "svg.fonttype": "none", "ps.fonttype": 42, "pdf.fonttype": 42,
    })


def legend(ax, **kwargs):
    options = dict(loc="upper right", fontsize=7.2, frameon=True,
                   handlelength=1.8, borderpad=0.35, labelspacing=0.3,
                   handletextpad=0.5)
    options.update(kwargs)
    box = ax.legend(**options)
    box.get_frame().set_linewidth(0.6)
    return box


def time_axis(ax, times):
    ax.set_xlim(times[0], times[-1])
    ax.set_xticks(np.linspace(times[0], times[-1], 6))
    ax.set_xlabel("Time step")
    ax.set_ylabel("Value")
    ax.tick_params(width=0.65)


def scientific_cost_axis(ax, maximum):
    """Use explicit scientific notation consistently in PNG and outlined EPS."""
    exponent = int(np.floor(np.log10(maximum)))
    if abs(exponent) < 3:
        return
    factor = 10.0 ** exponent
    ax.yaxis.set_major_formatter(FuncFormatter(
        lambda value, position: f"{value / factor:g}"))
    ax.yaxis.get_offset_text().set_visible(False)
    superscripts = str(exponent).translate(
        str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻"))
    ax.text(0.0, 1.015, "\u00d710" + superscripts,
            transform=ax.transAxes, ha="left", va="bottom", fontsize=10)


def save_figure(fig, folder, stem, cfg):
    # Fit the original long annotation wording inside each boxed axes.
    fig.canvas.draw()
    for ax in fig.axes:
        box = ax.get_legend()
        if box is None:
            continue
        for _ in range(3):
            renderer = fig.canvas.get_renderer()
            ratio = box.get_window_extent(renderer).width / (
                0.98 * ax.get_window_extent(renderer).width)
            if ratio <= 1:
                break
            for text in box.get_texts():
                text.set_fontsize(text.get_fontsize() / ratio * 0.98)
            fig.canvas.draw()
    fig.savefig(folder / (stem + ".png"), dpi=cfg["png_dpi"])
    # Portable vector outlines avoid dependence on the EPS viewer's TrueType
    # font support, while preserving exactly the same Times/math glyph shapes.
    for text in fig.findobj(match=Text):
        text.set_path_effects([
            path_effects.Stroke(linewidth=0, foreground=text.get_color())])
    fig.savefig(folder / (stem + ".eps"), format="eps")
    plt.close(fig)


def planar_figure(eta, ref):
    """Keep the two-column legend inside the axes, clear of every trajectory."""
    points = np.concatenate((eta[:, :, :2].reshape(-1, 2),
                             ref[:, :, :2].reshape(-1, 2)), axis=0)
    x_limits = (points[:, 0].min() - 1, points[:, 0].max() + 1)
    y_limits = (points[:, 1].min() - 1, points[:, 1].max() + 5)
    width = 3.9
    axes_height = width * 0.78 * ((y_limits[1] - y_limits[0]) /
                                  (x_limits[1] - x_limits[0]))
    height = axes_height + 0.50
    fig = plt.figure(figsize=(width, height))
    # Equal horizontal margins center the axes and legend in the paper column.
    ax = fig.add_axes([0.11, 0.43 / height, 0.78, axes_height / height])
    for i, agent in enumerate(("Leader", "Follower")):
        actual_color = BLUE if i == 0 else "#EDB120"
        desired_color = "#FF0000" if i == 0 else "#000000"
        ax.plot(eta[:, i, 0], eta[:, i, 1], "-", color=actual_color,
                label=agent + ": actual trajectory")
        ax.plot(ref[:, i, 0], ref[:, i, 1], "--", color=desired_color,
                linewidth=1.0, label=agent + ": desired trajectory")
        ax.plot(eta[0, i, 0], eta[0, i, 1], "o",
                color=actual_color, markersize=3.5)
        ax.plot(eta[-1, i, 0], eta[-1, i, 1], "s",
                color=actual_color, markersize=3.2)
        for k in (28, 68):
            ax.annotate("", xy=eta[k+2, i, :2], xytext=eta[k, i, :2],
                        arrowprops=dict(arrowstyle="->",
                                        color=actual_color, lw=0.9))
    ax.set_xlim(x_limits)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=9, steps=[1, 2, 5, 10]))
    ax.set_ylim(y_limits)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel(r"$x$ (m)", fontsize=10)
    ax.set_ylabel(r"$y$ (m)", fontsize=10)
    ax.tick_params(labelsize=8.5)
    # Matplotlib fills columns first: leader at left, follower at right.
    legend(ax, loc="upper center", ncol=2, fontsize=7.4,
           columnspacing=0.9, handlelength=1.6, handletextpad=0.45,
           labelspacing=0.3, borderpad=0.35, borderaxespad=0.55)
    return fig


def make_figures(m, run, physical, ref, costs, output, physical_cost):
    configure_style(m["cfg"])
    times = np.arange(len(run["state"]), dtype=float)
    states = run["state"].reshape(-1, 2, 6)
    mean_states = physical_cost["state_mean"]
    mean_forces = physical_cost["force_mean"]
    symbols = ["x", "y", r"\psi"]
    agents = ["leader", "follower"]
    files = []
    for i, agent in enumerate(agents):
        fig, axes = plt.subplots(3, 1, figsize=(3.9, 3.9))
        fig.subplots_adjust(left=0.15, right=0.97, bottom=0.10, top=0.97,
                            hspace=0.64)
        for j, ax in enumerate(axes):
            ax.plot(times, mean_states[:, i, j], color=BLUE,
                    label="the mean error in $" + symbols[j] + "$ of " + agent + " AUV")
            time_axis(ax, times)
            span = 1.5 if j < 2 else 0.15
            span = max(span, 1.8 * np.max(np.abs(mean_states[:, i, j])))
            ax.set_ylim(-span, span)
            ax.set_yticks([-span, 0, span])
            legend(ax)
        stem = f"fig{3+i}_{agent}_tracking_errors"
        save_figure(fig, output, stem, m["cfg"])
        files.append(stem)
    for i, agent in enumerate(agents):
        fig, axes = plt.subplots(3, 1, figsize=(3.9, 3.9))
        fig.subplots_adjust(left=0.15, right=0.97, bottom=0.10, top=0.97,
                            hspace=0.64)
        for j, ax in enumerate(axes):
            actual, desired = physical["eta"][:, i, j], ref[:, i, j]
            ax.plot(times, actual, color=BLUE if i == 0 else "#EDB120",
                    linestyle="-",
                    label="the actual $" + symbols[j] + "$ of " + agent + " AUV")
            ax.plot(times, desired, color="#FF0000" if i == 0 else "#000000",
                    linestyle="--", linewidth=1.0,
                    label="the desired $" + symbols[j] + "$ of " + agent + " AUV")
            time_axis(ax, times)
            lower = min(actual.min(), desired.min())
            upper = max(actual.max(), desired.max())
            span = max(upper - lower, 0.1)
            ax.set_ylim(lower - 0.10 * span, upper + 0.48 * span)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
            legend(ax, ncol=2, fontsize=6.6, columnspacing=0.7,
                   handlelength=1.5)
        stem = f"fig{5+i}_{agent}_actual_and_desired"
        save_figure(fig, output, stem, m["cfg"])
        files.append(stem)
    fig, ax = plt.subplots(figsize=(4.6, 2.9))
    fig.subplots_adjust(left=0.15, right=0.97, bottom=0.20, top=0.88)
    ax.plot(np.arange(len(costs)), costs, color=BLUE,
            label="the optimal value of cost function in the LF-AUV system")
    ax.set_xlabel(r"Time horizon $N$")
    ax.set_ylabel(r"Value of $\mathcal{J}_{Z,N}^{*}$")
    ax.set_xlim(0, len(costs) - 1)
    ax.set_xticks(np.linspace(0, len(costs) - 1, 6))
    ax.set_ylim(0, 1.3 * costs[-1])
    scientific_cost_axis(ax, costs[-1])
    legend(ax, fontsize=7.2)
    stem = "fig7_optimal_cost"
    save_figure(fig, output, stem, m["cfg"])
    files.append(stem)
    fig = planar_figure(physical["eta"], ref)
    stem = "fig8_two_auv_planar_trajectories"
    save_figure(fig, output, stem, m["cfg"])
    files.append(stem)
    fig, axes = plt.subplots(3, 2, figsize=(7.0, 4.6))
    fig.subplots_adjust(left=0.10, right=0.98, bottom=0.10, top=0.97,
                        wspace=0.27, hspace=0.65)
    names = ["surge force", "sway force", "yaw moment"]
    for j in range(3):
        for i, agent in enumerate(agents):
            ax = axes[j, i]
            values = mean_forces[:, i, j]
            ax.plot(times, values, color=BLUE,
                    label=f"the mean {names[j]} of {agent} AUV")
            time_axis(ax, times)
            ax.set_ylabel("Force (N)" if j < 2 else r"Moment (N$\cdot$m)")
            lower, upper = float(values.min()), float(values.max())
            span = max(upper - lower, 0.5)
            ax.set_ylim(lower - 0.12 * span, upper + 0.36 * span)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
            legend(ax, fontsize=7.3)
    stem = "fig9_two_auv_forces_and_moments"
    save_figure(fig, output, stem, m["cfg"])
    files.append(stem)
    if physical_cost is not None:
        fig, ax = plt.subplots(figsize=(4.6, 2.9))
        fig.subplots_adjust(left=0.15, right=0.97, bottom=0.20, top=0.88)
        horizons = np.arange(len(physical_cost["mean"]))
        ax.plot(horizons, physical_cost["mean"], color=BLUE,
                label="the cost with force and moment penalty in the LF-AUV system")
        ax.set_xlabel(r"Time horizon $N$")
        ax.set_ylabel(r"Value of $\mathcal{J}_{\tau,N}^{*}$")
        ax.set_xlim(horizons[0], horizons[-1])
        ax.set_xticks(np.linspace(horizons[0], horizons[-1], 6))
        ax.set_ylim(0, 1.3 * physical_cost["mean"][-1])
        scientific_cost_axis(ax, physical_cost["mean"][-1])
        legend(ax, fontsize=7.2)
        stem = "fig10_physical_force_cost"
        save_figure(fig, output, stem, m["cfg"])
        files.append(stem)
    return files


def save_data(m, sol, run, physical, times, ref, ref_v, ref_a, costs, data_dir):
    matrices = {key: m[key] for key in ("Ad", "Bd", "A10", "B10", "A", "B", "Q", "R")}
    matrices.update({key: sol[key] for key in ("P", "H", "S", "Omega")})
    np.savez_compressed(
        data_dir / "simulation_data.npz", time=times,
        state=run["state"], follower_common_estimate=run["estimate"],
        virtual_input=run["action"], reference=ref,
        reference_velocity=ref_v, reference_acceleration=ref_a,
        finite_horizon_cost=costs, **physical, **matrices)
    arrays, headers = [times[:, None]], ["time_s"]
    channels = [
        ("leader_error", run["state"][:, :6]),
        ("follower_error", run["state"][:, 6:]),
        ("follower_common_estimate", run["estimate"]),
        ("leader_virtual_input", run["action"][:, :3]),
        ("follower_virtual_input", run["action"][:, 3:]),
        ("leader_pose", physical["eta"][:, 0]),
        ("follower_pose", physical["eta"][:, 1]),
        ("leader_body_velocity", physical["nu"][:, 0]),
        ("follower_body_velocity", physical["nu"][:, 1]),
        ("leader_force", physical["tau"][:, 0]),
        ("follower_force", physical["tau"][:, 1]),
        ("follower_coupling_acceleration", physical["coupling_acceleration"][:, 1]),
    ]
    for name, array in channels:
        arrays.append(array)
        headers.extend(f"{name}_{i+1}" for i in range(array.shape[1]))
    np.savetxt(data_dir / "trajectory_and_inputs.csv", np.column_stack(arrays),
               delimiter=",", header=",".join(headers), comments="", fmt="%.12g")
    np.savetxt(data_dir / "finite_horizon_optimal_cost.csv",
               np.column_stack((np.arange(len(costs)), costs)),
               delimiter=",", header="N,expected_optimal_discounted_cost",
               comments="", fmt="%.12g")
    serializable = {key: value.tolist() for key, value in matrices.items()}
    serializable["initial_covariances"] = [x.tolist() for x in m["Xi"]]
    serializable["noise_covariances"] = [x.tolist() for x in m["W"]]
    (data_dir / "model_and_gains.json").write_text(
        json.dumps(serializable, indent=2), encoding="utf-8")


def validate(m, sol, run, physical, initial, noise, costs):
    changed_initial = initial.copy()
    changed_initial[1] += np.array([0.8, -0.6, 0.1, 0.02, -0.01, 0.01])
    changed_noise = noise.copy()
    changed_noise[:, 1] += np.array([0.01, -0.01, 0.001])
    perturbed = simulate_one(m, sol, changed_initial, changed_noise)
    leader_difference = float(np.max(np.abs(
        run["action"][:, :3] - perturbed["action"][:, :3])))
    estimate_difference = float(np.max(np.abs(
        run["estimate"] - perturbed["estimate"])))
    follower_difference = float(np.max(np.abs(
        run["action"][:, 3:] - perturbed["action"][:, 3:])))
    finite_errors = {}
    for n in (0, 1, 5, 20, len(costs) - 1):
        gains, private_gains = finite_gains(m, n + 1)
        by_moments = exact_policy_cost(m, gains, private_gains)
        finite_errors[str(n)] = abs(by_moments - costs[n])
    j_infinity = infinite_value(m, sol)
    moment_stages = max(
        350, int(np.ceil(np.log(1e-14) / np.log(m["gamma"]))))
    by_moments = exact_policy_cost(
        m, [sol["H"]] * moment_stages, [sol["Omega"]] * moment_stages)
    mc = monte_carlo_value(m, sol)
    relative_gaps = (j_infinity - costs) / j_infinity
    tolerance = float(m["cfg"].get("cost_convergence_relative_tolerance", 0.005))
    within_tolerance = np.flatnonzero(relative_gaps <= tolerance)
    convergence_n = int(within_tolerance[0]) if within_tolerance.size else None
    assert max(sol["are_relative_residuals"]) < 1e-11
    assert run["private_recursion_residual"] < 1e-10
    assert leader_difference < 1e-12 and estimate_difference < 1e-12
    assert follower_difference > 1e-3
    assert max(finite_errors.values()) < 1e-8
    assert abs(by_moments - j_infinity) < 1e-8
    assert physical["inverse_residual"] < 1e-10
    assert physical["coupled_residual"] < 1e-10
    assert np.diff(costs).min() >= -1e-9
    assert costs[-1] <= j_infinity + 1e-9
    assert abs(mc["mean"] - j_infinity) < 4 * mc["standard_error"]
    return dict(
        passed=True, common_private_spectral_radii=sol["radii"],
        riccati_residuals=sol["are_residuals"],
        riccati_relative_residuals=sol["are_relative_residuals"],
        cost_weight_scale=float(m["cfg"].get("cost_weight_scale", 1.0)),
        strict_lyapunov_inequality_minimum_eigenvalues=sol["margins"],
        private_gain_vs_common_H11_norm=float(
            np.linalg.norm(sol["Omega"] - sol["H"][3:, 6:])),
        private_recursion_residual=run["private_recursion_residual"],
        private_perturbation_leader_input_difference=leader_difference,
        private_perturbation_common_estimate_difference=estimate_difference,
        private_perturbation_follower_input_difference=follower_difference,
        force_inverse_residual=physical["inverse_residual"],
        force_plus_coupling_forward_dynamics_residual=physical["coupled_residual"],
        finite_value_vs_independent_forward_moments=finite_errors,
        infinite_value=j_infinity,
        infinite_value_vs_forward_moments_error=abs(by_moments - j_infinity),
        infinite_value_forward_moment_stages=moment_stages,
        finite_N100_value=float(costs[-1]),
        finite_N100_distance_to_infinite_value=float(j_infinity - costs[-1]),
        cost_convergence=dict(
            relative_tolerance=tolerance,
            first_N_within_tolerance=convergence_n,
            first_horizon_seconds_within_tolerance=(
                convergence_n * m["T"] if convergence_n is not None else None),
            relative_gap_at_N60=(
                float(relative_gaps[60]) if len(costs) > 60 else None),
            relative_gap_at_last_N=float(relative_gaps[-1])),
        monte_carlo=mc,
        plotted_tracking_statistic=(
            "figures 3/4: signed ensemble means; figures 5/6/8: fixed-seed realization"),
        plotted_cost_statistic="exact expected finite-horizon optimum",
        plotted_force_statistic=(
            "figure 9: ensemble mean of per-realization equation (75) inverse dynamics"),
        discretization="forward Euler",
        full_R_cross_blocks_retained=True,
        noise="persistent independent Gaussian acceleration noise; no decay")


def main():
    config_path = ROOT / "config.json"
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    output, data_dir = ROOT / "figures", ROOT / "data"
    output.mkdir(exist_ok=True)
    data_dir.mkdir(exist_ok=True)
    m = build_model(cfg)
    sol = stationary_solution(m)
    rng = np.random.default_rng(cfg["seed"])
    initial = m["mu"] + m["initial_std"] * rng.standard_normal((2, 6))
    noise = (rng.standard_normal((cfg["simulation_steps"], 2, 3))
             * m["acceleration_std"])
    run = simulate_one(m, sol, initial, noise)
    times = np.arange(len(run["state"])) * m["T"]
    ref, ref_v, ref_a = reference(times, cfg)
    physical = forces_and_states(m, run, ref, ref_v, ref_a)
    costs = finite_value_curve(m, cfg["simulation_steps"])
    report = validate(m, sol, run, physical, initial, noise, costs)
    force_cost = physical_cost_evaluation(
        m, sol, run, physical, ref, ref_v, ref_a)
    report["physical_force_cost"] = force_cost["validation"]
    save_data(m, sol, run, physical, times, ref, ref_v, ref_a, costs, data_dir)
    np.savez_compressed(
        data_dir / "physical_force_cost.npz",
        **{key: value for key, value in force_cost.items() if key != "validation"})
    np.savetxt(
        data_dir / "physical_force_cost.csv",
        np.column_stack((
            force_cost["time"], force_cost["mean"], force_cost["sem"],
            force_cost["state_component"], force_cost["force_component"])),
        delimiter=",", comments="", fmt="%.12g",
        header="time_s,expected_physical_cost,standard_error,state_component,force_moment_component")
    np.savez_compressed(
        data_dir / "ensemble_statistics.npz", time=force_cost["time"],
        state_mean=force_cost["state_mean"], state_sem=force_cost["state_sem"],
        force_mean=force_cost["force_mean"], force_sem=force_cost["force_sem"],
        expected_state_mean=force_cost["expected_state_mean"],
        runs=m["cfg"]["physical_cost_monte_carlo_runs"], seed=m["cfg"]["seed"] + 2)
    columns = [force_cost["time"][:, None]]
    headers = ["time_s"]
    for name in ["state_mean", "state_sem", "force_mean", "force_sem"]:
        values = force_cost[name].reshape(len(times), -1)
        columns.append(values)
        headers.extend(f"{name}_{j+1}" for j in range(values.shape[1]))
    np.savetxt(
        data_dir / "ensemble_statistics.csv", np.column_stack(columns),
        delimiter=",", comments="", fmt="%.12g", header=",".join(headers))
    files = make_figures(m, run, physical, ref, costs, output, force_cost)
    report["files"] = files
    report["config_sha256"] = hashlib.sha256(config_path.read_bytes()).hexdigest()
    (ROOT / "validation.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print("Generated eight PNG figures and eight matching EPS figures.")


if __name__ == "__main__":
    main()
