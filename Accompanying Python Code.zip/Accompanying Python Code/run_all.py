"""Reproduce the simulation, paper figure assets, and tracking RMSE table."""
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    scripts = ("simulate.py", "render_paper_figures.py", "compute_rmse.py")
    for index, script in enumerate(scripts, start=1):
        print("[{}/{}] Running {}".format(index, len(scripts), script), flush=True)
        subprocess.run([sys.executable, str(ROOT / script)], cwd=str(ROOT), check=True)
    print("Completed. Results are in data/, figures/, paper_figures/, and validation.json.")


if __name__ == "__main__":
    main()
