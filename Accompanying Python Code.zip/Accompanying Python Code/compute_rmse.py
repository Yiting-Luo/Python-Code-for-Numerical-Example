"""Reproduce the pooled tracking RMSE table from saved ensemble statistics."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent


def compute_rows():
    config = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    validation = json.loads((ROOT / "validation.json").read_text(encoding="utf-8"))
    config_hash = hashlib.sha256((ROOT / "config.json").read_bytes()).hexdigest()
    if config_hash != validation["config_sha256"]:
        raise ValueError("Regenerate the simulation statistics for the current config.")
    with np.load(ROOT / "data" / "ensemble_statistics.npz") as data:
        times = data["time"]
        means = data["state_mean"]
        sem = data["state_sem"]
        runs = int(data["runs"])
        seed = int(data["seed"])
    # SEM = sample_std(ddof=1)/sqrt(runs). Therefore the empirical second
    # moment is mean**2 + (runs-1)*SEM**2, not the square of the mean.
    second_moments = means**2 + (runs - 1) * sem**2
    rows = []
    for start in (0, 20):
        selected = (times >= start) & (times <= 100)
        if not selected.any():
            raise ValueError("The saved data do not cover the specified RMSE interval.")
        for i, agent in enumerate(("Leader", "Follower")):
            position_mse = second_moments[selected, i, :2].sum(axis=1).mean()
            heading_mse = second_moments[selected, i, 2].mean()
            rows.append({
                "auv": agent,
                "interval_start_s": start,
                "interval_end_s": 100,
                "sampling_instants": int(selected.sum()),
                "position_rmse_m": float(np.sqrt(position_mse)),
                "heading_rmse_rad": float(np.sqrt(heading_mse)),
            })
    metadata = {
        "runs": runs,
        "seed": seed,
        "discount_factor": config["discount_factor"],
        "sampling_period_s": config["sampling_period"],
        "position_metric": "RMS planar Euclidean tracking distance; no division by 2",
        "heading_metric": "RMS continuous-angle tracking error in radians",
        "aggregation": "pool squared errors over runs and time, then take one square root",
        "second_moment_reconstruction": "mean**2 + (runs-1)*SEM**2",
        "source": "data/ensemble_statistics.npz",
        "rows": rows,
    }
    return rows, metadata


def main():
    rows, metadata = compute_rows()
    output = ROOT / "data"
    with (output / "tracking_rmse.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (output / "tracking_rmse.json").write_text(
        json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
