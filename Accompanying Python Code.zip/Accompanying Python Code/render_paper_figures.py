"""Render single-column paper figures and tracking panels from saved data.

Run after simulate.py. No model, sample, controller, or original figure is changed.
"""
import argparse
import json
from pathlib import Path

import numpy as np
from matplotlib.ticker import MaxNLocator

import simulate as sim


ROOT = Path(__file__).resolve().parent


def save(fig, output, stem, cfg):
    sim.save_figure(fig, output, stem, cfg)
    # save_figure leaves text as vector outlines, also suitable for PDF.
    fig.savefig(output / (stem + ".pdf"), format="pdf")


def tracking_panels(cfg, output, state_mean):
    """Keep the original mean curves readable when two panels share one column."""
    times = np.arange(len(state_mean), dtype=float)
    symbols = ("x", "y", r"\psi")
    for i, agent in enumerate(("leader", "follower")):
        fig, axes = sim.plt.subplots(3, 1, figsize=(1.92, 3.55))
        fig.subplots_adjust(left=0.25, right=0.94, bottom=0.10, top=0.97,
                            hspace=0.60)
        for j, ax in enumerate(axes):
            values = state_mean[:, i, j]
            ax.plot(times, values, color=sim.BLUE,
                    label="the mean error in $" + symbols[j] + "$")
            sim.time_axis(ax, times)
            ax.set_xticks([times[0], times[len(times)//2], times[-1]])
            ax.set_xlabel("Time step", fontsize=8.5)
            ax.set_ylabel("Value", fontsize=8.5, labelpad=2)
            ax.tick_params(labelsize=8, pad=2)
            span = 1.5 if j < 2 else 0.15
            span = max(span, 1.8 * np.max(np.abs(values)))
            ax.set_ylim(-span, span)
            ax.set_yticks([-span, 0, span])
            sim.legend(ax, fontsize=6.9, handlelength=1.2,
                       handletextpad=0.35, borderpad=0.3)
        save(fig, output, "tracking_errors_" + agent + "_panel", cfg)


def pose_panels(cfg, output, eta, ref):
    """Preserve the original single-realization curves and the figure-8 colors."""
    times = np.arange(len(eta), dtype=float)
    symbols = ("x", "y", r"\psi")
    for i, agent in enumerate(("leader", "follower")):
        fig, axes = sim.plt.subplots(3, 1, figsize=(1.92, 3.55))
        fig.subplots_adjust(left=0.25, right=0.94, bottom=0.10, top=0.97,
                            hspace=0.60)
        for j, ax in enumerate(axes):
            actual, desired = eta[:, i, j], ref[:, i, j]
            ax.plot(times, actual, color=sim.BLUE if i == 0 else "#EDB120",
                    linestyle="-", label="the actual $" + symbols[j] + "$")
            ax.plot(times, desired, color="#FF0000" if i == 0 else "#000000",
                    linestyle="--", linewidth=1.0,
                    label="the desired $" + symbols[j] + "$")
            sim.time_axis(ax, times)
            ax.set_xticks([times[0], times[len(times)//2], times[-1]])
            ax.set_xlabel("Time step", fontsize=8.5)
            ax.set_ylabel("Value", fontsize=8.5, labelpad=2)
            ax.tick_params(labelsize=8, pad=2)
            lower = min(actual.min(), desired.min())
            upper = max(actual.max(), desired.max())
            span = max(upper - lower, 0.1)
            # Reserve room for the two-row legend above both plotted curves.
            ax.set_ylim(lower - 0.10 * span, upper + 0.95 * span)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=3))
            sim.legend(ax, fontsize=6.9, handlelength=1.2,
                       handletextpad=0.35, borderpad=0.3, labelspacing=0.2)
        save(fig, output, "actual_desired_" + agent + "_panel", cfg)


def force_panels(cfg, output, force_mean):
    """Draw each AUV separately before placing the panels side by side in TeX."""
    times = np.arange(len(force_mean), dtype=float)
    names = ("surge force", "sway force", "yaw moment")
    for i, agent in enumerate(("leader", "follower")):
        fig, axes = sim.plt.subplots(3, 1, figsize=(1.92, 3.55))
        fig.subplots_adjust(left=0.25, right=0.94, bottom=0.10, top=0.97,
                            hspace=0.60)
        for j, ax in enumerate(axes):
            values = force_mean[:, i, j]
            ax.plot(times, values, color=sim.BLUE,
                    label="the mean " + names[j])
            sim.time_axis(ax, times)
            ax.set_xticks([times[0], times[len(times)//2], times[-1]])
            ax.set_xlabel("Time step", fontsize=8.5)
            ax.set_ylabel("Force (N)" if j < 2 else r"Moment (N$\cdot$m)",
                          fontsize=8.5, labelpad=2)
            ax.tick_params(labelsize=8, pad=2)
            lower, upper = float(values.min()), float(values.max())
            span = max(upper - lower, 0.5)
            ax.set_ylim(lower - 0.12 * span, upper + 0.60 * span)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=3))
            sim.legend(ax, fontsize=6.9, handlelength=1.2,
                       handletextpad=0.35, borderpad=0.3)
        save(fig, output, "forces_and_moments_" + agent + "_panel", cfg)


def main(tracking_only=False, pose_only=False, force_only=False, planar_only=False):
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    sim.configure_style(cfg)
    output = ROOT / "paper_figures"
    output.mkdir(exist_ok=True)
    with np.load(ROOT / "data" / "simulation_data.npz") as source:
        eta, ref = source["eta"], source["reference"]
    if planar_only:
        fig = sim.planar_figure(eta, ref)
        save(fig, output, "fig8_two_auv_planar_trajectories", cfg)
        print("Rendered planar trajectories from unchanged saved data.")
        return
    with np.load(ROOT / "data" / "physical_force_cost.npz") as source:
        force_mean = source["force_mean"]
        state_mean = source["state_mean"]
    if force_only:
        force_panels(cfg, output, force_mean)
        print("Rendered separate leader/follower force panels from unchanged mean data.")
        return
    if pose_only:
        pose_panels(cfg, output, eta, ref)
        print("Rendered actual/desired panels from unchanged trajectory data.")
        return
    tracking_panels(cfg, output, state_mean)
    if tracking_only:
        print("Rendered leader/follower tracking panels from unchanged mean data.")
        return
    pose_panels(cfg, output, eta, ref)
    force_panels(cfg, output, force_mean)
    fig = sim.planar_figure(eta, ref)
    save(fig, output, "fig8_two_auv_planar_trajectories", cfg)

    print("Rendered single-column paper panels and planar trajectories from saved data.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument("--tracking-only", action="store_true",
                           help="render only the two mean-error panels")
    selection.add_argument("--pose-only", action="store_true",
                           help="render only the two actual/desired panels")
    selection.add_argument("--force-only", action="store_true",
                           help="render only the separate leader/follower force panels")
    selection.add_argument("--planar-only", action="store_true",
                           help="render only the two-AUV planar trajectories")
    args = parser.parse_args()
    main(tracking_only=args.tracking_only, pose_only=args.pose_only,
         force_only=args.force_only, planar_only=args.planar_only)
