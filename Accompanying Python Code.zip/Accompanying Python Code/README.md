# Accompanying Python Code

Reproducible numerical example for the leader-follower AUV control study with asymmetric information. The package contains the Python source code and all simulation parameters. Generated figures and data are reproduced by running the code.

## Installation and execution

The verified environment uses Python 3.9, NumPy 2.0.2, and Matplotlib 3.9.4. MATLAB, SciPy, LaTeX, and Ghostscript are not required to execute the Python programs. Matplotlib uses a noninteractive backend, so no graphical desktop is needed.

Open a terminal in this folder and install the dependencies:

```sh
python -m pip install -r requirements.txt
```

To install the versions used for verification in a compatible Python environment, use `requirements-tested.txt` instead.

Run the complete reproduction:

```sh
python run_all.py
```

The entry point runs the following commands in order:

```sh
python simulate.py
python render_paper_figures.py
python compute_rmse.py
```

All input files are resolved relative to the scripts. All generated output is written inside this folder. Running again replaces the generated outputs using the parameters in `config.json`.

Times New Roman is used when installed. Matplotlib can use a fallback font on systems without it; install the font to match the manuscript typography.

## Included files

| File | Purpose |
| --- | --- |
| `run_all.py` | Run the complete simulation, figure rendering, and RMSE calculation. |
| `simulate.py` | Build the model, solve the common and private Riccati equations, simulate the controller, calculate performance indices, validate the computations, and generate eight source figures. |
| `render_paper_figures.py` | Render the single-column planar trajectory figure and the paired panels used in the manuscript from saved simulation data. |
| `compute_rmse.py` | Calculate the position and heading RMSEs from the saved ensemble statistics. |
| `config.json` | Model parameters, cost weights, reference trajectory, initial distributions, noise levels, seeds, and plotting settings. |
| `requirements.txt` | Required Python libraries. |
| `requirements-tested.txt` | Library versions used for verification. |

## Mapping to the current manuscript

The source image filenames retain their original numbering. The current manuscript numbers differ because several images are combined. Panel letters and captions are added by the manuscript's LaTeX layout.

| Manuscript item | Generated file or files |
| --- | --- |
| Fig. 3: two-AUV planar trajectories | `paper_figures/fig8_two_auv_planar_trajectories.*` |
| Fig. 4(a), (b): leader and follower mean tracking errors | `paper_figures/tracking_errors_leader_panel.*`, `tracking_errors_follower_panel.*` |
| Fig. 5(a), (b): leader and follower actual and desired components | `paper_figures/actual_desired_leader_panel.*`, `actual_desired_follower_panel.*` |
| Fig. 6(a), (b): leader and follower mean forces and moments | `paper_figures/forces_and_moments_leader_panel.*`, `forces_and_moments_follower_panel.*` |
| Fig. 7(a): finite-horizon optimal cost | `figures/fig7_optimal_cost.*` |
| Fig. 7(b): cost with physical force and moment penalties | `figures/fig10_physical_force_cost.*` |
| Table I: position and heading tracking RMSEs | `data/tracking_rmse.csv`, `data/tracking_rmse.json` |

The `figures/` folder contains the eight source plots as 600 dpi PNG and vector EPS files. The `paper_figures/` folder contains PNG, EPS, and PDF assets. EPS files can be included in the manuscript using its existing LaTeX workflow.

After a complete simulation, individual paper assets can be redrawn without resampling:

```sh
python render_paper_figures.py --planar-only
python render_paper_figures.py --tracking-only
python render_paper_figures.py --pose-only
python render_paper_figures.py --force-only
```

## Simulation and statistical definitions

The sampling period is 1 s and the plotted interval is 0--100 s. The discount factor is 0.92. The reference path is sinusoidal, with a prescribed relative reference offset for the follower. Reference velocities and accelerations are evaluated analytically. The error state uses inertial velocity errors at the sampling instant, and the discrete model uses forward Euler matrices. Both coupling matrices are nonzero.

The common and private feedback gains are obtained from two discounted Riccati equations. The full control weighting matrix retains its nonzero cross blocks. Parameters and random seeds are specified in `config.json`.

Persistent, independent, zero-mean Gaussian acceleration disturbances are used. For each AUV, their component standard deviations are `[0.15, 0.15, 0.018]`. The tracking-error and force/moment mean curves use 4096 realizations. The actual-versus-desired and planar trajectory figures show one fixed-seed realization. Ensemble means are calculated from signed errors; a mean near zero does not imply zero RMSE.

The virtual-input cost is the expected finite-horizon optimum for each horizon, with zero terminal weight. The physical-input cost is evaluated under the computed controller, using reconstructed total actuator forces and moments in its quadratic penalties. The simulation propagates the discrete error model and reconstructs physical inputs by nominal inverse dynamics.

Table I uses pooled squared errors across all 4096 realizations and all sampling instants within each interval, followed by a single square root. Position RMSE uses the planar squared distance `(x-x_d)^2 + (y-y_d)^2`, without dividing by two. Heading RMSE uses the continuous heading error in radians. Both 0--100 s and 20--100 s intervals include their endpoints. The RMSE calculation reconstructs empirical second moments from the saved mean and standard error of the mean, rather than squaring the ensemble mean alone.

## Generated data and verification

- `data/simulation_data.npz`: representative states, estimates, controls, reconstructed inputs, and reference trajectory.
- `data/trajectory_and_inputs.csv`: representative trajectory and input data.
- `data/model_and_gains.json`: model matrices and control gains.
- `data/finite_horizon_optimal_cost.csv`: finite-horizon expected optimal values.
- `data/physical_force_cost.npz` and `.csv`: physical-input cost statistics and components.
- `data/ensemble_statistics.npz` and `.csv`: ensemble state and input means and standard errors.
- `data/tracking_rmse.csv` and `.json`: the manuscript RMSE table and statistical metadata.
- `validation.json`: stability checks, Riccati residuals, information-structure checks, inverse-dynamics checks, and independent cost evaluations.

For the supplied configuration, representative reference results are:

| Quantity | Value |
| --- | ---: |
| Infinite-horizon virtual-input optimal cost | 10980.47 |
| Finite-horizon virtual-input optimal cost at N = 100 | 10978.70 |
| Physical-input cumulative cost at N = 100 | 13542.73 |

| AUV | Interval (s) | Position RMSE (m) | Heading RMSE (rad) |
| --- | --- | ---: | ---: |
| Leader | 0--100 | 0.3269 | 0.02461 |
| Follower | 0--100 | 0.3146 | 0.02408 |
| Leader | 20--100 | 0.3064 | 0.02229 |
| Follower | 20--100 | 0.3039 | 0.02227 |

Small numerical or typography differences can occur across library versions and platforms. After changing `config.json`, run the complete reproduction again so that figures, statistics, and validation results use the same parameters.
